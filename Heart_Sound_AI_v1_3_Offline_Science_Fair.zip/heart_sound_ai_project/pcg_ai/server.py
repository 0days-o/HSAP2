"""LAN-only live heart-sound research dashboard and ESP32 receiver.

The dashboard displays raw acoustic waveform/spectrogram data and optional
rolling model output. It is an educational research tool, not a medical device.
Keep it on a trusted private LAN; do not port-forward it or expose it publicly.
"""
from __future__ import annotations

from collections import deque
from datetime import datetime, timezone
import csv
import hmac
import io
import json
import os
from pathlib import Path
import socket
import threading
import time

from flask import Flask, jsonify, request, send_file, abort
import numpy as np
import soundfile as sf
from scipy.signal import resample_poly, stft
from werkzeug.utils import secure_filename

from .audio import pcm16_to_model_spectrogram
from .predict import latest_model_path, load_keras_model, score_wav

SAMPLE_RATE = 8_000
CHUNK_SECONDS = 0.5
CHUNK_SAMPLES = int(SAMPLE_RATE * CHUNK_SECONDS)
ROLLING_SECONDS = 10
ROLLING_CHUNKS = int(ROLLING_SECONDS / CHUNK_SECONDS)
PREDICTION_WINDOW_SECONDS = 8
PREDICTION_INTERVAL_SECONDS = 2
MAX_SESSION_SECONDS = 600  # 10 minutes per session
MAX_SESSION_SAMPLES = SAMPLE_RATE * MAX_SESSION_SECONDS
RECORDINGS_DIR = Path(os.getenv("PCG_RECORDINGS_DIR", "recordings"))
MODEL_PATH = Path(os.getenv("PCG_MODEL_PATH")) if os.getenv("PCG_MODEL_PATH") else latest_model_path()
UPLOAD_TOKEN = os.getenv("PCG_UPLOAD_TOKEN", "")

app = Flask(__name__, template_folder="templates")
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024
RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)

MODEL = None
MODEL_LOAD_ERROR = None
if MODEL_PATH is not None and MODEL_PATH.exists():
    try:
        MODEL = load_keras_model(MODEL_PATH)
        print(f"Loaded research model from {MODEL_PATH}")
    except Exception as exc:  # receiver should still work for audio visualization
        MODEL_LOAD_ERROR = str(exc)
        print(f"WARNING: model could not be loaded ({exc}). Dashboard will show audio only.")
else:
    print("No trained model found. Dashboard will show live audio without AI predictions until a model is trained.")


class LiveSession:
    """Thread-safe buffers for a single live classroom demonstration session."""

    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.active = False
        self.started_at: float | None = None
        self.started_iso: str | None = None
        self.last_chunk_at: float | None = None
        self.rolling: deque[np.ndarray] = deque(maxlen=ROLLING_CHUNKS)
        self.session_chunks: list[np.ndarray] = []
        self.total_samples = 0
        self.chunk_count = 0
        self.last_sequence: int | None = None
        self.sequence_gaps = 0
        self.prediction: dict | None = None
        self.prediction_history: list[dict] = []
        self.last_prediction_scheduled_seconds = 0.0
        self.prediction_running = False
        self.saved_wav: Path | None = None
        self.saved_csv: Path | None = None
        self.events: deque[dict] = deque(maxlen=12)

    def event(self, message: str, kind: str = "info") -> None:
        self.events.appendleft({"time": datetime.now().astimezone().strftime("%H:%M:%S"), "message": message, "kind": kind})

    def reset(self) -> None:
        with self.lock:
            self.active = False
            self.started_at = None
            self.started_iso = None
            self.last_chunk_at = None
            self.rolling.clear()
            self.session_chunks.clear()
            self.total_samples = 0
            self.chunk_count = 0
            self.last_sequence = None
            self.sequence_gaps = 0
            self.prediction = None
            self.prediction_history.clear()
            self.last_prediction_scheduled_seconds = 0.0
            self.prediction_running = False
            self.saved_wav = None
            self.saved_csv = None
            self.events.clear()


LIVE = LiveSession()


def _check_token() -> bool:
    if not UPLOAD_TOKEN:
        return True
    provided = request.headers.get("X-Upload-Token", "")
    return hmac.compare_digest(provided, UPLOAD_TOKEN)


def _rolling_snapshot() -> np.ndarray:
    with LIVE.lock:
        chunks = list(LIVE.rolling)
    if not chunks:
        return np.empty(0, dtype=np.int16)
    return np.concatenate(chunks).astype(np.int16, copy=False)


def _prediction_worker(pcm: np.ndarray, elapsed_seconds: float) -> None:
    """Run model inference off the device-upload request thread."""
    try:
        if MODEL is None:
            return
        raw_rms = float(np.sqrt(np.mean(np.square(pcm.astype(np.float32)))))
        if raw_rms < 4.0:
            with LIVE.lock:
                LIVE.prediction = {
                    "status": "waiting_for_signal",
                    "message": "Signal level is extremely low; prediction paused.",
                    "elapsed_seconds": round(elapsed_seconds, 1),
                }
            return
        tensor = pcm16_to_model_spectrogram(pcm, input_sr=SAMPLE_RATE)
        score = float(np.asarray(MODEL.predict(np.expand_dims(tensor, axis=0), verbose=0)).reshape(-1)[0])
        prediction = {
            "status": "ready",
            "model_score_abnormal_reference_class": score,
            "model_score_percent": round(score * 100.0, 1),
            "model_output_label": "Abnormal-reference-like" if score >= 0.5 else "Normal-reference-like",
            "threshold": 0.5,
            "elapsed_seconds": round(elapsed_seconds, 1),
            "window_seconds": PREDICTION_WINDOW_SECONDS,
            "updated_at": datetime.now().astimezone().strftime("%H:%M:%S"),
            "interpretation": "Model score for a dataset reference class; not a clinical probability or diagnosis.",
        }
        with LIVE.lock:
            LIVE.prediction = prediction
            LIVE.prediction_history.append(prediction.copy())
            LIVE.event(f"New research-model output: {prediction['model_output_label']}", "prediction")
    except Exception as exc:
        with LIVE.lock:
            LIVE.prediction = {"status": "error", "message": f"Prediction failed: {exc}"}
            LIVE.event("Model inference error; waveform capture continues.", "warning")
    finally:
        with LIVE.lock:
            LIVE.prediction_running = False


def _maybe_schedule_prediction() -> None:
    if MODEL is None:
        return
    with LIVE.lock:
        available = LIVE.total_samples / SAMPLE_RATE
        if not LIVE.active or available < PREDICTION_WINDOW_SECONDS:
            return
        if LIVE.prediction_running or available - LIVE.last_prediction_scheduled_seconds < PREDICTION_INTERVAL_SECONDS:
            return
        rolling_chunks = list(LIVE.rolling)
        if not rolling_chunks:
            return
        pcm = np.concatenate(rolling_chunks).astype(np.int16, copy=False)
        needed = PREDICTION_WINDOW_SECONDS * SAMPLE_RATE
        if pcm.size < needed:
            return
        pcm = pcm[-needed:].copy()
        LIVE.prediction_running = True
        LIVE.last_prediction_scheduled_seconds = available
        elapsed = available
    threading.Thread(target=_prediction_worker, args=(pcm, elapsed), daemon=True).start()


def _spectrogram_payload(samples: np.ndarray) -> list[list[float]]:
    if samples.size < 256:
        return []
    # Match the model's 2 kHz analysis band while plotting a compact recent view.
    x = resample_poly(samples.astype(np.float32) / 32768.0, 1, 4)
    nperseg = min(256, len(x))
    if nperseg < 128:
        return []
    _, _, z = stft(x, fs=2_000, nperseg=nperseg, noverlap=nperseg - 32, boundary=None)
    power_db = 20.0 * np.log10(np.maximum(np.abs(z), 1e-7))
    power_db = power_db[: min(96, power_db.shape[0]), :]
    floor = float(np.max(power_db) - 55.0)
    normalized = np.clip((power_db - floor) / 55.0, 0.0, 1.0)
    # Spectrogram display is low-frequency sound visualization, not diagnostic analysis.
    return np.round(normalized, 3).tolist()


def _state_payload() -> dict:
    with LIVE.lock:
        rolling = list(LIVE.rolling)
        samples = np.concatenate(rolling).astype(np.int16, copy=False) if rolling else np.empty(0, dtype=np.int16)
        total_seconds = LIVE.total_samples / SAMPLE_RATE
        connected = bool(LIVE.active and LIVE.last_chunk_at and time.monotonic() - LIVE.last_chunk_at < 3.0)
        active = LIVE.active
        prediction = LIVE.prediction.copy() if LIVE.prediction else None
        events = list(LIVE.events)
        chunk_count = LIVE.chunk_count
        gaps = LIVE.sequence_gaps
        started_iso = LIVE.started_iso
        saved_wav = LIVE.saved_wav.name if LIVE.saved_wav and LIVE.saved_wav.exists() else None
        saved_csv = LIVE.saved_csv.name if LIVE.saved_csv and LIVE.saved_csv.exists() else None
        running = LIVE.prediction_running
    if samples.size:
        tail = samples[-2 * SAMPLE_RATE:]
        # Downsample for a compact JSON response, retaining enough points for a smooth plot.
        stride = max(1, int(np.ceil(tail.size / 700)))
        waveform = np.round(tail[::stride].astype(np.float32) / 32768.0, 4).tolist()
        rms = float(np.sqrt(np.mean(np.square(tail.astype(np.float32)))))
        peak = int(np.max(np.abs(tail.astype(np.int32))))
        clipped = float(np.mean(np.abs(tail.astype(np.int32)) >= 32700) * 100.0)
        spectrum = _spectrogram_payload(tail)
    else:
        waveform, rms, peak, clipped, spectrum = [], 0.0, 0, 0.0, []
    if not active:
        status = "Stopped"
    elif connected:
        status = "Streaming"
    else:
        status = "Waiting for ESP32"
    return {
        "active": active,
        "status": status,
        "device_connected": connected,
        "model_loaded": MODEL is not None,
        "model_filename": str(MODEL_PATH) if MODEL is not None else None,
        "model_load_error": MODEL_LOAD_ERROR,
        "sample_rate_hz": SAMPLE_RATE,
        "session_duration_seconds": round(total_seconds, 1),
        "rolling_window_seconds": round(min(samples.size / SAMPLE_RATE, ROLLING_SECONDS), 1),
        "chunks_received": chunk_count,
        "sequence_gaps": gaps,
        "started_at": started_iso,
        "rms_counts": round(rms, 1),
        "peak_counts": peak,
        "clipped_percent": round(clipped, 3),
        "signal_level": "Very low" if samples.size and rms < 4 else ("Clipping" if clipped > 0.5 else ("Signal received" if samples.size else "No signal yet")),
        "waveform": waveform,
        "spectrogram": spectrum,
        "spectrogram_frequency_max_hz": 1_000,
        "prediction": prediction,
        "prediction_running": running,
        "events": events,
        "saved_wav": saved_wav,
        "saved_csv": saved_csv,
        "max_session_seconds": MAX_SESSION_SECONDS,
        "notice": "Educational research output only. Not for diagnosis, screening, or treatment decisions.",
    }


@app.get("/")
def dashboard():
    return send_file(Path(__file__).parent / "templates" / "dashboard.html")


@app.get("/api/network")
def network_status():
    """Local-only receiver diagnostics; makes no external requests."""
    try:
        host_ip = socket.gethostbyname(socket.gethostname())
    except OSError:
        host_ip = "unknown"
    with LIVE.lock:
        streaming = LIVE.last_chunk_at is not None and (time.time() - LIVE.last_chunk_at) < 3.0
        age = round(time.time() - LIVE.last_chunk_at, 1) if LIVE.last_chunk_at else None
    return jsonify({
        "receiver": "online",
        "receiver_host_ip": host_ip,
        "receiver_port": int(os.getenv("PCG_PORT", "8000")),
        "device_streaming": streaming,
        "last_chunk_age_seconds": age,
        "expected_esp32_ap_ip": "192.168.4.1",
        "expected_receiver_ip": os.getenv("PCG_RECEIVER_IP", "192.168.4.2"),
        "network_mode": "ESP32 SoftAP / local-only",
        "internet_required": False
    })


@app.get("/api/live/status")
def device_status():
    # The ESP32 polls this endpoint and only sends audio while the dashboard session is active.
    with LIVE.lock:
        return jsonify({"active": LIVE.active, "sample_rate_hz": SAMPLE_RATE, "chunk_seconds": CHUNK_SECONDS})


@app.post("/api/live/start")
def start_session():
    with LIVE.lock:
        if LIVE.active:
            return jsonify({"ok": True, "message": "Session is already running."})
        LIVE.active = True
        LIVE.started_at = time.monotonic()
        LIVE.started_iso = datetime.now().astimezone().isoformat(timespec="seconds")
        LIVE.last_chunk_at = None
        LIVE.rolling.clear()
        LIVE.session_chunks.clear()
        LIVE.total_samples = 0
        LIVE.chunk_count = 0
        LIVE.last_sequence = None
        LIVE.sequence_gaps = 0
        LIVE.prediction = {"status": "warming_up", "message": "Waiting for eight seconds of audio before the first model output."}
        LIVE.prediction_history.clear()
        LIVE.last_prediction_scheduled_seconds = 0.0
        LIVE.prediction_running = False
        LIVE.saved_wav = None
        LIVE.saved_csv = None
        LIVE.events.clear()
        LIVE.event("Live session started. Waiting for ESP32 audio.")
    return jsonify({"ok": True, "model_loaded": MODEL is not None, "message": "Live session started."})


@app.post("/api/live/stop")
def stop_session():
    with LIVE.lock:
        LIVE.active = False
        chunks = list(LIVE.session_chunks)
        prediction_rows = list(LIVE.prediction_history)
        total_samples = LIVE.total_samples
        LIVE.event("Live session stopped.")
    if not chunks or total_samples == 0:
        return jsonify({"ok": True, "saved": False, "message": "No audio was received during this session."})
    pcm = np.concatenate(chunks).astype(np.int16, copy=False)
    stamp = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
    wav_path = RECORDINGS_DIR / f"live_session_{stamp}.wav"
    csv_path = RECORDINGS_DIR / f"live_session_{stamp}_predictions.csv"
    sf.write(str(wav_path), pcm, SAMPLE_RATE, subtype="PCM_16")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["updated_at", "elapsed_seconds", "model_output_label", "model_score_abnormal_reference_class", "window_seconds", "interpretation"])
        writer.writeheader()
        for row in prediction_rows:
            writer.writerow({
                "updated_at": row.get("updated_at", ""),
                "elapsed_seconds": row.get("elapsed_seconds", ""),
                "model_output_label": row.get("model_output_label", ""),
                "model_score_abnormal_reference_class": row.get("model_score_abnormal_reference_class", ""),
                "window_seconds": row.get("window_seconds", ""),
                "interpretation": row.get("interpretation", ""),
            })
    with LIVE.lock:
        LIVE.saved_wav = wav_path
        LIVE.saved_csv = csv_path
        LIVE.event(f"Saved WAV: {wav_path.name}", "success")
    return jsonify({"ok": True, "saved": True, "wav": wav_path.name, "predictions_csv": csv_path.name, "duration_seconds": round(len(pcm) / SAMPLE_RATE, 2)})


@app.post("/api/live/clear")
def clear_session():
    LIVE.reset()
    return jsonify({"ok": True, "message": "Current dashboard buffers cleared. Previously saved files were not deleted."})


@app.post("/api/live/chunk")
def receive_live_chunk():
    if not _check_token():
        return jsonify({"error": "Unauthorized"}), 401
    with LIVE.lock:
        if not LIVE.active:
            return jsonify({"error": "No live session is active."}), 409
    body = request.get_data(cache=False, as_text=False)
    if not body or len(body) % 2 or len(body) > SAMPLE_RATE * 2:
        return jsonify({"error": "Expected up to one second of signed 16-bit mono PCM."}), 400
    pcm = np.frombuffer(body, dtype="<i2").copy()
    if pcm.size < int(SAMPLE_RATE * 0.1):
        return jsonify({"error": "Audio chunk is too short; send at least 0.1 seconds."}), 400
    seq_text = request.headers.get("X-Chunk-Index", "")
    try:
        sequence = int(seq_text) if seq_text else None
    except ValueError:
        sequence = None
    with LIVE.lock:
        if not LIVE.active:
            return jsonify({"error": "Session stopped while receiving audio."}), 409
        if sequence is not None and LIVE.last_sequence is not None and sequence > LIVE.last_sequence + 1:
            LIVE.sequence_gaps += sequence - LIVE.last_sequence - 1
        if sequence is not None:
            LIVE.last_sequence = sequence
        LIVE.rolling.append(pcm)
        if LIVE.total_samples < MAX_SESSION_SAMPLES:
            allowed = MAX_SESSION_SAMPLES - LIVE.total_samples
            accepted = pcm[:allowed]
            if accepted.size:
                LIVE.session_chunks.append(accepted)
                LIVE.total_samples += int(accepted.size)
        LIVE.chunk_count += 1
        LIVE.last_chunk_at = time.monotonic()
        if LIVE.total_samples >= MAX_SESSION_SAMPLES:
            LIVE.active = False
            LIVE.event("Maximum 10-minute session reached; recording stopped automatically.", "warning")
    _maybe_schedule_prediction()
    return jsonify({"ok": True, "received_samples": int(pcm.size), "chunk_index": sequence}), 200


@app.get("/api/live/state")
def live_state():
    return jsonify(_state_payload())


@app.get("/api/live/download/<path:filename>")
def download_recording(filename: str):
    safe_name = secure_filename(filename)
    if not safe_name:
        abort(404)
    path = (RECORDINGS_DIR / safe_name).resolve()
    if path.parent != RECORDINGS_DIR.resolve() or not path.exists() or not path.is_file():
        abort(404)
    return send_file(path, as_attachment=True)


@app.post("/upload")
def legacy_upload():
    """Keep compatibility with the prior one-shot 8-second firmware."""
    if not _check_token():
        return jsonify({"error": "Unauthorized upload token"}), 401
    body = request.get_data(cache=False, as_text=False)
    if len(body) < SAMPLE_RATE * 2 * 2 or len(body) > SAMPLE_RATE * 2 * 10 or len(body) % 2:
        return jsonify({"error": "Expected 2 to 10 seconds of 8 kHz int16 PCM."}), 400
    pcm = np.frombuffer(body, dtype="<i2")
    now = datetime.now(timezone.utc).astimezone().strftime("%Y%m%d_%H%M%S_%f")
    wav_path = RECORDINGS_DIR / f"pcg_{now}.wav"
    sf.write(str(wav_path), pcm, SAMPLE_RATE, subtype="PCM_16")
    result = {"saved_file": wav_path.name, "sample_rate_hz": SAMPLE_RATE, "duration_seconds": round(len(pcm) / SAMPLE_RATE, 2), "model_loaded": MODEL is not None, "warning": "Research/demo output only; not a diagnosis."}
    if MODEL is not None:
        try:
            result.update(score_wav(MODEL, wav_path))
        except Exception as exc:
            result["scoring_error"] = str(exc)
    return jsonify(result), 200


def _local_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("192.0.2.1", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        return "YOUR-COMPUTER-IP"


if __name__ == "__main__":
    print("\nHEART SOUND AI — LIVE RESEARCH DASHBOARD")
    print("Open on this computer: http://127.0.0.1:8000")
    print(f"Open on the same Wi-Fi network: http://{_local_ip()}:8000")
    print("On the dashboard, press START LIVE, then power the ESP32.")
    print("Private network only. Do not port-forward or expose this receiver publicly.")
    print("Educational research prototype only — not a medical device.\n")
    app.run(host="0.0.0.0", port=8000, debug=False, threaded=True)
