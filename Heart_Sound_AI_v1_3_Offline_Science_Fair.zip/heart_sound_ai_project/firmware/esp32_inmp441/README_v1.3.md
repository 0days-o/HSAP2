# v1.3 Offline SoftAP setup

1. Change `AP_PASSWORD` in the sketch before the demonstration.
2. Set `SERVER_BASE_URL` to `http://192.168.4.2:8000` (or your chosen receiver IP).
3. Flash the firmware to a classic ESP32 DevKit/WROOM board.
4. Start the Python receiver on the MacBook before joining the hotspot.
5. Join Wi-Fi `HeartSound-Lab` from the MacBook.
6. In macOS System Settings → Wi-Fi → Details → TCP/IP, set Configure IPv4: Manually:
   - IP address: `192.168.4.2`
   - Subnet mask: `255.255.255.0`
   - Router: `192.168.4.1`
7. Open `http://127.0.0.1:8000` on the MacBook.
8. Press Start Live. Stop & Save writes the WAV and prediction CSV; the dashboard exposes both download links.

For a different receiver IP, change `SERVER_BASE_URL` and assign the same IP to the MacBook. Keep both on the same `192.168.4.x/24` subnet. No router or internet is needed for live capture.
