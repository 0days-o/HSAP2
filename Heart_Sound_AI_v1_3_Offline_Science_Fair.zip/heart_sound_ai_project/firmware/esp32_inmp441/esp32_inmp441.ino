/*
  HEART SOUND AI — OFFLINE SOFTAP STREAMING FIRMWARE (v1.3)
  Board: classic ESP32 DevKit / ESP32-WROOM-style board
  Microphone: INMP441 I2S MEMS module

  The ESP32 polls the Python receiver. When you press START LIVE in the
  browser dashboard, it records and uploads 0.5-second chunks of 8 kHz,
  signed 16-bit mono PCM. Press STOP & SAVE in the dashboard to end a session.

  Educational research only. Not a medical device. Use controlled playback
  recordings for demonstrations unless a school-approved protocol says otherwise.
*/
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ESP_I2S.h>

// ---- EDIT THESE SETTINGS BEFORE UPLOADING ----
const char *AP_SSID = "HeartSound-Lab";
const char *AP_PASSWORD = "HeartSound2026"; // Change before your event.
// Set this to the MacBook static IPv4 address.
const char *SERVER_BASE_URL = "http://192.168.4.2:8000";
// Optional. If used, set PCG_UPLOAD_TOKEN in the computer environment too.
const char *UPLOAD_TOKEN = "";

// INMP441 -> classic ESP32 DevKit
constexpr int I2S_BCLK = 26; // SCK / BCLK
constexpr int I2S_WS   = 25; // WS / LRCLK
constexpr int I2S_SD   = 33; // SD / DOUT

constexpr uint32_t SAMPLE_RATE = 8000;
constexpr size_t CHUNK_SAMPLES = 4000; // 0.5 seconds
constexpr uint32_t STATUS_POLL_MS = 500;

I2SClass I2S;
int16_t pcm[CHUNK_SAMPLES];
uint32_t chunkIndex = 0;
unsigned long lastStatusPoll = 0;
bool sessionActive = false;

String endpoint(const char *path) {
  return String(SERVER_BASE_URL) + path;
}

void addAuthHeader(HTTPClient &http) {
  if (UPLOAD_TOKEN[0] != '\0') http.addHeader("X-Upload-Token", UPLOAD_TOKEN);
}

bool startAccessPoint() {
  WiFi.mode(WIFI_AP);
  WiFi.setSleep(false);
  IPAddress apIP(192, 168, 4, 1);
  IPAddress gateway(192, 168, 4, 1);
  IPAddress subnet(255, 255, 255, 0);
  if (!WiFi.softAPConfig(apIP, gateway, subnet)) return false;
  if (!WiFi.softAP(AP_SSID, AP_PASSWORD, 6, false, 2)) return false;
  Serial.println("NETWORK: HeartSound-Lab hotspot ready.");
  Serial.print("ESP32 address: ");
  Serial.println(WiFi.softAPIP());
  Serial.println("MacBook receiver default: 192.168.4.2:8000");
  return true;
}

bool receiverReachable() {
  if (WiFi.softAPgetStationNum() == 0) {
    Serial.println("NETWORK: no computer joined HeartSound-Lab.");
    return false;
  }
  HTTPClient http;
  http.setTimeout(1800);
  if (!http.begin(endpoint("/api/network"))) return false;
  addAuthHeader(http);
  int code = http.GET();
  http.end();
  if (code == HTTP_CODE_OK) {
    Serial.println("NETWORK: receiver reachable.");
    return true;
  }
  Serial.printf("NETWORK: receiver check failed (HTTP %d); retrying.\\n", code);
  return false;
}

bool setupMicrophone() {
  // Connect INMP441 L/R to GND for the left channel.
  I2S.setPins(I2S_BCLK, I2S_WS, -1, I2S_SD);
  if (!I2S.begin(I2S_MODE_STD, SAMPLE_RATE,
                 I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_MONO)) {
    Serial.println("ERROR: I2S start failed. Verify the board, Arduino-ESP32 core, and wiring.");
    return false;
  }
  return true;
}

bool serverRequestsStreaming() {
  if (!receiverReachable()) return false;
  HTTPClient http;
  http.setTimeout(2500);
  if (!http.begin(endpoint("/api/live/status"))) return false;
  addAuthHeader(http);
  int code = http.GET();
  String body = code == HTTP_CODE_OK ? http.getString() : "";
  http.end();
  if (code != HTTP_CODE_OK) {
    Serial.printf("Receiver status check failed: HTTP %d\n", code);
    return false;
  }
  return body.indexOf("\"active\":true") >= 0 || body.indexOf("\"active\": true") >= 0;
}

bool captureAndSendChunk() {
  // Capture 0.5 seconds. The server stores the raw PCM and creates the plots.
  size_t filled = 0;
  while (filled < CHUNK_SAMPLES) {
    int32_t raw = 0;
    size_t bytesRead = I2S.readBytes(reinterpret_cast<char *>(&raw), sizeof(raw));
    if (bytesRead == sizeof(raw)) {
      pcm[filled++] = static_cast<int16_t>(raw >> 16);
    }
    if (WiFi.softAPgetStationNum() == 0) return false;
  }

  HTTPClient http;
  http.setTimeout(3000);
  if (!http.begin(endpoint("/api/live/chunk"))) {
    Serial.println("Could not open live chunk endpoint.");
    return false;
  }
  http.addHeader("Content-Type", "application/octet-stream");
  http.addHeader("X-Chunk-Index", String(chunkIndex++));
  addAuthHeader(http);
  uint8_t *payload = reinterpret_cast<uint8_t *>(pcm);
  const size_t payloadBytes = sizeof(pcm);
  int code = http.POST(payload, payloadBytes);
  if (code < 200 || code >= 300) {
    Serial.printf("Chunk upload failed: HTTP %d\n", code);
    String response = http.getString();
    if (response.length()) Serial.println(response);
  }
  http.end();
  return code >= 200 && code < 300;
}

void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.println();
  Serial.println("HEART SOUND AI — LIVE ESP32 RECORDER");
  Serial.println("Join HeartSound-Lab from your receiver computer, then open the dashboard and press START LIVE.");
  Serial.println("This is an educational audio-research prototype, not a medical device.");
  if (!setupMicrophone()) {
    Serial.println("Restart after fixing the microphone wiring.");
    while (true) delay(1000);
  }
  if (!startAccessPoint()) {
    Serial.println("FATAL: hotspot startup failed.");
    while (true) delay(1000);
  }
}

void loop() {
  // Keep the ESP32 hotspot alive; retry as soon as the computer reconnects.
  if (WiFi.softAPgetStationNum() == 0) {
    sessionActive = false;
    delay(300);
    return;
  }

  if (millis() - lastStatusPoll >= STATUS_POLL_MS) {
    lastStatusPoll = millis();
    bool requested = serverRequestsStreaming();
    if (requested != sessionActive) {
      sessionActive = requested;
      Serial.println(sessionActive ? "Dashboard session active — streaming audio." : "Dashboard session stopped — microphone stream idle.");
    }
  }

  if (sessionActive) {
    if (!captureAndSendChunk()) {
      Serial.println("Streaming paused after upload/network error; checking receiver again.");
      sessionActive = false;
      delay(300);
    }
  } else {
    delay(40);
  }
}
