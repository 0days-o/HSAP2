# v1.3 — Offline Science Fair Edition

- ESP32 SoftAP hotspot: `HeartSound-Lab`, address `192.168.4.1`.
- Configurable receiver target in firmware: `SERVER_BASE_URL`.
- Local `/api/network` receiver diagnostics endpoint.
- Dashboard network panel with receiver status, streaming state and last-packet age.
- ESP32 retries receiver checks while keeping its hotspot available after transient disconnections.
- Existing local WAV recording and prediction-history CSV export retained.
- Live data flow requires no cloud or external API.
