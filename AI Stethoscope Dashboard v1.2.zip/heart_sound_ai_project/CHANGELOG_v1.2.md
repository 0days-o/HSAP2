# Version 1.2 — Live dashboard

- Added a browser-based, dark neon-style research dashboard at `http://127.0.0.1:8000`.
- Added live waveform, rolling spectrogram, sample-level diagnostics, ESP32 connection status, and event log.
- Added browser controls to start, stop, clear, and save live sessions.
- Added ESP32 polling of `/api/live/status` and 0.5-second audio chunk uploads to `/api/live/chunk`.
- Added rolling 8-second model inference, refreshed approximately every 2 seconds after warm-up when a trained model is loaded.
- Added WAV and prediction-history CSV downloads after stopping a session.
- Added shared live PCM preprocessing to align 8 kHz device audio with the model's 2 kHz training preprocessing.
- Kept the earlier one-shot `/upload` API for backwards compatibility.

This remains a school research prototype. It has not been clinically validated and must not be used for screening, diagnosis, or treatment decisions. Prefer controlled playback recordings for demonstrations.
