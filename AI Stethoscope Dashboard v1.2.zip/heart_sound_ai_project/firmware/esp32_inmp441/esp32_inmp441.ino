/*
  HEART SOUND AI — LIVE AUDIO STREAMING FIRMWARE (v1.2)
  Board: classic ESP32 DevKit / ESP32-WROOM-style board
  Microphone: INMP441 I2S MEMS module

  The ESP32 polls the Python receiver. When you press START LIVE in the
  browser dashboard, it records and uploads 0.5-second chunks of 8 kHz,
  signed 16-bit mono PCM. Press STOP & SAVE in the dashboard to end a session.

  Educational research only. Not a medical device. Use controlled playback
  recordings for demonstrations unless a school-approved protocol says otherwise.
*/
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ESP_I2S.h>

// ---- EDIT THESE SETTINGS BEFORE UPLOADING ----
const char *WIFI_SSID = "REPLACE_WITH_2_4_GHZ_WIFI_NAME";
const char *WIFI_PASSWORD = "REPLACE_WITH_WIFI_PASSWORD";
// Use the computer's LAN IP printed when you start menu option 3.
const char *SERVER_BASE_URL = "http://192.168.1.80:8000";
// Optional. If used, set PCG_UPLOAD_TOKEN in the computer environment too.
const char *UPLOAD_TOKEN = "";

// INMP441 -> classic ESP32 DevKit
constexpr int I2S_BCLK = 26; // SCK / BCLK
constexpr int I2S_WS   = 25; // WS / LRCLK
constexpr int I2S_SD   = 33; // SD / DOUT

constexpr uint32_t SAMPLE_RATE = 8000;
constexpr size_t CHUNK_SAMPLES = 4000; // 0.5 seconds
constexpr uint32_t STATUS_POLL_MS = 500;

I2SClass I2S;
int16_t pcm[CHUNK_SAMPLES];
uint32_t chunkIndex = 0;
unsigned long lastStatusPoll = 0;
bool sessionActive = false;

String endpoint(const char *path) {
  return String(SERVER_BASE_URL) + path;
}

void addAuthHeader(HTTPClient &http) {
  if (UPLOAD_TOKEN[0] != '\0') http.addHeader("X-Upload-Token", UPLOAD_TOKEN);
}

bool connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return true;
  Serial.printf("Connecting to Wi-Fi: %s\n", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  const unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < 20000) {
    delay(250);
    Serial.print('.');
  }
  Serial.println();
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi connection failed. Check credentials and use a 2.4 GHz network.");
    return false;
  }
  Serial.print("Wi-Fi connected. ESP32 IP: ");
  Serial.println(WiFi.localIP());
  return true;
}

bool setupMicrophone() {
  // Connect INMP441 L/R to GND for the left channel.
  I2S.setPins(I2S_BCLK, I2S_WS, -1, I2S_SD);
  if (!I2S.begin(I2S_MODE_STD, SAMPLE_RATE,
                 I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_MONO)) {
    Serial.println("ERROR: I2S start failed. Verify the board, Arduino-ESP32 core, and wiring.");
    return false;
  }
  return true;
}

bool serverRequestsStreaming() {
  if (!connectWiFi()) return false;
  HTTPClient http;
  http.setTimeout(2500);
  if (!http.begin(endpoint("/api/live/status"))) return false;
  addAuthHeader(http);
  int code = http.GET();
  String body = code == HTTP_CODE_OK ? http.getString() : "";
  http.end();
  if (code != HTTP_CODE_OK) {
    Serial.printf("Receiver status check failed: HTTP %d\n", code);
    return false;
  }
  return body.indexOf("\"active\":true") >= 0 || body.indexOf("\"active\": true") >= 0;
}

bool captureAndSendChunk() {
  // Capture 0.5 seconds. The server stores the raw PCM and creates the plots.
  size_t filled = 0;
  while (filled < CHUNK_SAMPLES) {
    int32_t raw = 0;
    size_t bytesRead = I2S.readBytes(reinterpret_cast<char *>(&raw), sizeof(raw));
    if (bytesRead == sizeof(raw)) {
      pcm[filled++] = static_cast<int16_t>(raw >> 16);
    }
    if (WiFi.status() != WL_CONNECTED) return false;
  }

  HTTPClient http;
  http.setTimeout(3000);
  if (!http.begin(endpoint("/api/live/chunk"))) {
    Serial.println("Could not open live chunk endpoint.");
    return false;
  }
  http.addHeader("Content-Type", "application/octet-stream");
  http.addHeader("X-Chunk-Index", String(chunkIndex++));
  addAuthHeader(http);
  const uint8_t *payload = reinterpret_cast<const uint8_t *>(pcm);
  const size_t payloadBytes = sizeof(pcm);
  int code = http.POST(payload, payloadBytes);
  if (code < 200 || code >= 300) {
    Serial.printf("Chunk upload failed: HTTP %d\n", code);
    String response = http.getString();
    if (response.length()) Serial.println(response);
  }
  http.end();
  return code >= 200 && code < 300;
}

void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.println();
  Serial.println("HEART SOUND AI — LIVE ESP32 RECORDER");
  Serial.println("Open the dashboard and press START LIVE to begin streaming.");
  Serial.println("This is an educational audio-research prototype, not a medical device.");
  if (!setupMicrophone()) {
    Serial.println("Restart after fixing the microphone wiring.");
    while (true) delay(1000);
  }
  connectWiFi();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
    delay(500);
    return;
  }
  if (millis() - lastStatusPoll >= STATUS_POLL_MS) {
    lastStatusPoll = millis();
    bool requested = serverRequestsStreaming();
    if (requested != sessionActive) {
      sessionActive = requested;
      Serial.println(sessionActive ? "Dashboard session active — streaming audio." : "Dashboard session stopped — microphone stream idle.");
    }
  }
  if (sessionActive) {
    if (!captureAndSendChunk()) {
      Serial.println("Streaming paused after upload/network error; checking receiver again.");
      sessionActive = false;
      delay(300);
    }
  } else {
    delay(40);
  }
}
