# ESP32 + INMP441 Live Streaming Firmware (v1.2)

This sketch streams short blocks of signed 16-bit, 8 kHz mono audio to the project's live browser dashboard. It no longer waits for a serial `r` command.

## Before flashing

1. Use a classic ESP32 DevKit / ESP32-WROOM-style board. The pin mapping may need changes for ESP32-S3, C3, or other variants.
2. Wire the INMP441 according to `../../hardware/wiring_diagram.svg`.
3. Install a current Arduino-ESP32 3.x board package so `ESP_I2S.h` is available.
4. Edit `WIFI_SSID`, `WIFI_PASSWORD`, and `SERVER_BASE_URL` near the top of the sketch. Set the server base URL to the computer's LAN IP, for example `http://192.168.1.80:8000` (no `/upload` suffix).
5. Keep the computer and ESP32 on the same trusted 2.4 GHz private Wi-Fi network.
6. Compile and flash. Open Serial Monitor at 115200 baud.

## How to use

1. Start menu option **3** on the computer.
2. Open `http://127.0.0.1:8000` on the computer, or the printed LAN address from another device on the same network.
3. Press **Start live** in the browser dashboard.
4. The ESP32 polls `/api/live/status`; when the session becomes active, it streams 0.5-second audio chunks to `/api/live/chunk`.
5. Press **Stop & save** in the dashboard. The server saves a WAV file and a prediction-history CSV inside `recordings/`.

The browser dashboard can display waveform, spectrogram, signal diagnostics, and session status without a trained model. Rolling model outputs require a successfully trained model in `experiments/`. The first output appears after eight seconds of audio and refreshes as more chunks arrive.

## Data alignment note

The INMP441 provides 24-bit audio in a 32-bit I²S slot. The sketch keeps the upper 16 bits (`raw >> 16`) for PCM16 transmission. Verify the captured waveform amplitude on your exact breakout. If the signal is almost silent or consistently clipped, stop and inspect I²S configuration and wiring before interpreting any signal.

## Network and safety

The receiver binds to the local network so the ESP32 can reach it. Keep it on a trusted private LAN, allow Python through the firewall only on private networks, and do not create router port-forwarding rules or expose port 8000 publicly. Optional upload-token protection is supported through `PCG_UPLOAD_TOKEN` on the computer and `UPLOAD_TOKEN` in the sketch.

Educational research only. Not a medical device. Do not use the model output for screening, diagnosis, or treatment decisions. Prefer controlled playback recordings for demonstrations.
