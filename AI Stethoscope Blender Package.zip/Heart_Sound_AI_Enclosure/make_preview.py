from pathlib import Path
import trimesh
import numpy as np

root=Path(__file__).resolve().parent
scene=trimesh.Scene()

def mat(color):
    return np.array(color,dtype=np.uint8)

base=trimesh.load(root/'Enclosure_Base.stl',force='mesh')
base.visual.face_colors=mat([35,53,76,255])
scene.add_geometry(base,geom_name='Enclosure_Base_PRINT',node_name='Enclosure_Base_PRINT')

lid=trimesh.load(root/'Enclosure_Lid.stl',force='mesh')
lid.apply_translation([0,0,20])
lid.visual.face_colors=mat([42,90,130,255])
scene.add_geometry(lid,geom_name='Enclosure_Lid_Exploded',node_name='Enclosure_Lid_Exploded')

def add_box(name, extents, center, color):
    m=trimesh.creation.box(extents=extents)
    m.apply_translation(center)
    m.visual.face_colors=mat(color)
    scene.add_geometry(m,geom_name=name,node_name=name)

# Approximate non-printable electronics placeholders.
add_box('ESP32_DevKit_approx_52x28', [52,28,1.6], [-30,0,6.2], [20,140,90,255])
add_box('INMP441_breakout_approx_15x12', [15,12,1.6], [35,0,6.2], [25,90,170,255])
# Capsule cylinder sitting above microphone board.
c=trimesh.creation.cylinder(radius=2.0,height=1.1,sections=48)
c.apply_translation([35,0,7.55])
c.visual.face_colors=mat([90,105,125,255])
scene.add_geometry(c,geom_name='Mic_capsule_placeholder',node_name='Mic_capsule_placeholder')
# USB connector placeholder.
add_box('USB_connector_placeholder',[8.5,7,3.8],[-57,0,6.8],[185,190,200,255])

scene.export(root/'Heart_Sound_AI_Enclosure_Quick_View.glb')
print('Wrote GLB')
