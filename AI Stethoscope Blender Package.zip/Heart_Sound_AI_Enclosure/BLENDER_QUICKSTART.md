# Create your native Blender project

The package includes a Blender scene-builder script and a GLB scene for immediate import. The native `.blend` file is generated on your computer by Blender itself.

## Fastest way to view the model
1. Open Blender.
2. Choose **File → Import → glTF 2.0 (.glb)**.
3. Select `Heart_Sound_AI_Enclosure_Quick_View.glb`.
4. Choose **File → Save As** and save it as `Heart_Sound_AI_Enclosure.blend`.

The quick-view scene includes the tray, exploded lid, and approximate colored electronics placeholders.

## Full editable scene with labels and lights
1. Keep every file in this folder together.
2. Open Blender and select the **Scripting** workspace.
3. In the Text Editor, choose **Open** and select `Create_Enclosure_Blender.py`.
4. Click **Run Script**.
5. The script imports the two STL print parts, adds separate collections for the electronics placeholders, colored wire routes, labels, camera and lighting, then saves `Heart_Sound_AI_Enclosure.blend` in this folder.

## Print parts
- `Enclosure_Base.stl`: print the outside bottom flat on the build plate.
- `Enclosure_Lid.stl`: flip it so the outside top face is on the build plate; the internal skirt and microphone guide point upward.
- `Enclosure_Assembly.step`: neutral CAD assembly if you want to inspect or modify the solids in a CAD package.

The Blender scene is an exploded visualization. The STEP assembly has the parts placed together. STL files are the authoritative print files.
