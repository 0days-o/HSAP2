"""Parametric enclosure geometry for the Heart Sound AI prototype.
Run with Python + CadQuery to regenerate STL/STEP parts.
All dimensions are millimetres. Generic fit; measure your own boards before printing.
"""
import cadquery as cq
from cadquery import exporters
from pathlib import Path

OUT = Path(__file__).resolve().parent
# Main case dimensions
L, W, H = 118.0, 78.0, 24.0
WALL, FLOOR, CORNER = 2.4, 2.4, 6.0
# Electronics assumptions: ESP32 DevKit approx 52 x 28 mm; INMP441 breakout approx 15 x 12 mm
ESP_CENTER = (-30.0, 0.0)
MIC_CENTER = (35.0, 0.0)
USB_OPENING_W, USB_OPENING_H = 13.5, 6.0
MIC_PORT_D = 6.2
SCREW_X, SCREW_Y = 52.0, 32.0


def rounded_box(x, y, z, height, radius, center=(0, 0, 0)):
    return (cq.Workplane("XY").box(x, y, height)
            .edges("|Z").fillet(radius)
            .translate((center[0], center[1], center[2])))

# Base shell: open top with 2.4 mm floor and walls.
base = rounded_box(L, W, H, H, CORNER, (0, 0, H/2))
inner = rounded_box(L-2*WALL, W-2*WALL, H-FLOOR+1.0, H-FLOOR+1.0,
                    max(1.0, CORNER-WALL), (0, 0, FLOOR+(H-FLOOR+1.0)/2))
base = base.cut(inner)

# Four corner screw towers fused to the floor/walls, with pilot bores for M2.5 screws.
for sx in (-SCREW_X, SCREW_X):
    for sy in (-SCREW_Y, SCREW_Y):
        boss = (cq.Workplane("XY").center(sx, sy).circle(4.4).extrude(17.0)
                .translate((0, 0, FLOOR)))
        base = base.union(boss)
        bore = (cq.Workplane("XY").center(sx, sy).circle(1.15).extrude(19.5)
                .translate((0, 0, FLOOR-0.1)))
        base = base.cut(bore)

# USB access opening through the left end wall; sized to accommodate common USB-C / micro-USB DevKits.
usb_cut = (cq.Workplane("YZ").workplane(offset=-L/2-1.0)
           .center(0, 6.8).rect(USB_OPENING_W, 6.0).extrude(WALL+2.0))
# YZ workplane coords are (y,z), offset is X.
base = base.cut(usb_cut)

# Universal cable-tie slots: two paired positions for ESP32 board and two paired positions for mic board.
# They avoid relying on any vendor-specific board-hole spacing.
def slot_cut(x, y, sx=2.6, sy=7.0):
    return (cq.Workplane("XY").center(x, y).rect(sx, sy).extrude(FLOOR+1.0)
            .translate((0, 0, -0.5)))
# ESP32 area: two pairs at board ends.
for x in (ESP_CENTER[0]-25.0, ESP_CENTER[0]+25.0):
    for y in (-16.5, 16.5):
        base = base.cut(slot_cut(x, y))
# INMP441 small module tie slots; leave centre microphone-port area open.
for x in (MIC_CENTER[0]-10.0, MIC_CENTER[0]+10.0):
    for y in (-8.5, 8.5):
        base = base.cut(slot_cut(x, y, 2.2, 5.5))

# Low rails supporting ESP32 PCB edges (keeps underside components clear).
for y in (-13.8, 13.8):
    rail = (cq.Workplane("XY").center(ESP_CENTER[0], y).box(48.0, 2.0, 2.0)
            .translate((0, 0, FLOOR+1.0)))
    base = base.union(rail)
# Small support pads under the microphone breakout, leaving its acoustic port clear.
for dx in (-7.0, 7.0):
    for dy in (-5.0, 5.0):
        pad = (cq.Workplane("XY").center(MIC_CENTER[0]+dx, dy).box(2.5, 2.5, 2.0)
               .translate((0, 0, FLOOR+1.0)))
        base = base.union(pad)

# Lid: top plate plus shallow locating skirt that slips into the base opening.
LID_T = 2.4
lid_top_z = H
lid = rounded_box(L, W, LID_T, LID_T, CORNER, (0, 0, lid_top_z+LID_T/2))
skirt_h = 5.0
skirt_outer = rounded_box(L-2*WALL-0.45, W-2*WALL-0.45, skirt_h, skirt_h,
                          max(1.0, CORNER-WALL), (0, 0, H-skirt_h/2))
skirt_inner = rounded_box(L-2*WALL-0.45-3.6, W-2*WALL-0.45-3.6, skirt_h+1.0, skirt_h+1.0,
                          max(0.8, CORNER-WALL-1.8), (0, 0, H-skirt_h/2))
skirt = skirt_outer.cut(skirt_inner)
lid = lid.union(skirt)

# Lid clearance holes for M2.5 screws.
for sx in (-SCREW_X, SCREW_X):
    for sy in (-SCREW_Y, SCREW_Y):
        hole = (cq.Workplane("XY").center(sx, sy).circle(1.45).extrude(LID_T+skirt_h+1.0)
                .translate((0, 0, H-skirt_h-0.2)))
        lid = lid.cut(hole)

# Acoustic inlet through lid. The funnel extension reaches close to the assumed top-facing mic port.
# Top opening has shallow counterbore for a soft silicone grommet; the central 6.2 mm bore passes through.
mic_x, mic_y = MIC_CENTER
mic_bore = (cq.Workplane("XY").center(mic_x, mic_y).circle(MIC_PORT_D/2).extrude(LID_T+skirt_h+0.5)
            .translate((0, 0, H-skirt_h-0.1)))
lid = lid.cut(mic_bore)
# Grommet seat, 9 mm diameter x 1 mm deep from the upper surface.
grommet_recess = (cq.Workplane("XY").center(mic_x, mic_y).circle(4.6).extrude(1.0)
                  .translate((0, 0, H+LID_T-1.0)))
lid = lid.cut(grommet_recess)

# Funnel/tube guide on underside of lid: thickened collar with bore aligned to module.
# Add collar, then re-cut bore through it.
collar = (cq.Workplane("XY").center(mic_x, mic_y).circle(5.0).extrude(16.5)
          .translate((0, 0, H-16.5)))
lid = lid.union(collar)
collar_bore = (cq.Workplane("XY").center(mic_x, mic_y).circle(MIC_PORT_D/2).extrude(17.0)
               .translate((0, 0, H-16.6)))
lid = lid.cut(collar_bore)

# Small raised top labels are intentionally omitted from printable geometry; add them in Blender scene.

# Export individual print parts and a neutral STEP assembly.
exporters.export(base, str(OUT / "Enclosure_Base.stl"), tolerance=0.08, angularTolerance=0.1)
exporters.export(lid, str(OUT / "Enclosure_Lid.stl"), tolerance=0.08, angularTolerance=0.1)
assembly = cq.Assembly(name="Heart_Sound_AI_Enclosure")
assembly.add(base, name="Base")
assembly.add(lid, name="Lid", loc=cq.Location(cq.Vector(0, 0, 3.5)))
assembly.export(str(OUT / "Enclosure_Assembly.step"), exportType="STEP", tolerance=0.08, angularTolerance=0.1)
print("Exported enclosure base, lid, and assembly to", OUT)
