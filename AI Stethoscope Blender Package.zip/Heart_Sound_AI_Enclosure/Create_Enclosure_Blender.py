"""Heart Sound AI enclosure scene builder.

Open this script in Blender's Scripting workspace and click Run Script.
It imports Enclosure_Base.stl and Enclosure_Lid.stl, adds editable hardware
placeholders/wires/labels, and saves Heart_Sound_AI_Enclosure.blend beside
this script. The two STL files are the printable parts.

Dimensions are millimetres. Board placeholders are approximate and are NOT
mechanical drawings of every ESP32 / INMP441 vendor variant.
"""
import bpy
import math
from pathlib import Path
from mathutils import Vector

# Find the folder containing this script when run from Blender's Text Editor.
try:
    ROOT = Path(__file__).resolve().parent
except NameError:
    text_block = next((t for t in bpy.data.texts if t.filepath), None)
    if text_block is None:
        raise RuntimeError("Open this .py file in Blender's Text Editor before running it.")
    ROOT = Path(bpy.path.abspath(text_block.filepath)).resolve().parent

BASE_STL = ROOT / "Enclosure_Base.stl"
LID_STL = ROOT / "Enclosure_Lid.stl"
if not BASE_STL.exists() or not LID_STL.exists():
    raise FileNotFoundError("Keep Enclosure_Base.stl and Enclosure_Lid.stl in the same folder as this script.")

# Clear default scene.
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.materials, bpy.data.curves, bpy.data.cameras, bpy.data.lights):
    for block in list(datablocks):
        if block.users == 0:
            datablocks.remove(block)

scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 0.001  # one Blender unit represents one millimetre
scene.unit_settings.length_unit = 'MILLIMETERS'

# Collections keep print parts and illustrative hardware separate.
def collection(name):
    c = bpy.data.collections.new(name)
    scene.collection.children.link(c)
    return c
print_col = collection("01 - PRINTABLE PARTS (export these STLs)")
elect_col = collection("02 - ELECTRONICS PLACEHOLDERS (visual reference only)")
wire_col = collection("03 - WIRING REFERENCE (visual only)")
label_col = collection("04 - LABELS AND DIMENSIONS (not for printing)")
set_col = collection("05 - DISPLAY SETUP")


def move_to_collection(obj, col):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    col.objects.link(obj)
    return obj


def material(name, color, metallic=0.0, roughness=0.38):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Metallic"].default_value = metallic
        bsdf.inputs["Roughness"].default_value = roughness
    return m

mat_case = material("Case - graphite PLA", (0.055, 0.085, 0.13), 0.15, 0.3)
mat_lid = material("Lid - blue graphite", (0.08, 0.15, 0.24), 0.12, 0.3)
mat_pcb = material("ESP32 PCB - green", (0.025, 0.28, 0.16), 0.05, 0.45)
mat_micpcb = material("INMP441 breakout - blue", (0.025, 0.20, 0.38), 0.05, 0.4)
mat_chip = material("Microphone capsule - dark metal", (0.10, 0.13, 0.17), 0.65, 0.25)
mat_usb = material("USB connector - silver", (0.55, 0.60, 0.67), 0.75, 0.23)
mat_red = material("Wire - 3V3 red", (0.85, 0.04, 0.035))
mat_black = material("Wire - ground black", (0.035, 0.045, 0.06))
mat_yellow = material("Wire - SCK yellow", (0.95, 0.65, 0.035))
mat_blue = material("Wire - WS blue", (0.02, 0.32, 0.95))
mat_green = material("Wire - SD green", (0.03, 0.72, 0.20))
mat_text = material("Label - cool cyan", (0.05, 0.85, 1.0), 0.0, 0.3)
mat_floor = material("Display ground", (0.018, 0.025, 0.045), 0.0, 0.8)

# STL import works in Blender 4+; keep compatibility with older versions.
def import_stl(path):
    if hasattr(bpy.ops.wm, "stl_import"):
        bpy.ops.wm.stl_import(filepath=str(path))
    else:
        bpy.ops.import_mesh.stl(filepath=str(path))
    return bpy.context.selected_objects[0]

base = import_stl(BASE_STL)
base.name = "Enclosure_Base_PRINT"
base.data.name = "Enclosure_Base_Mesh"
base.data.materials.append(mat_case)
move_to_collection(base, print_col)

lid = import_stl(LID_STL)
lid.name = "Enclosure_Lid_PRINT (exploded display)"
lid.data.name = "Enclosure_Lid_Mesh"
lid.data.materials.append(mat_lid)
# Move the lid upward for an exploded assembly view. Original STL remains unchanged on disk.
lid.location.z += 20.0
move_to_collection(lid, print_col)


def cube_obj(name, dims, loc, mat, col, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = dims
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if mat:
        obj.data.materials.append(mat)
    if bevel:
        mod = obj.modifiers.new("Soft component edges", 'BEVEL')
        mod.width = bevel
        mod.segments = 3
    move_to_collection(obj, col)
    return obj


def cylinder_obj(name, radius, depth, loc, mat, col, vertices=48):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc)
    obj = bpy.context.object
    obj.name = name
    if mat:
        obj.data.materials.append(mat)
    move_to_collection(obj, col)
    return obj

# Illustrative board placeholders. Coordinates are aligned to the parametric print design.
# ESP32 DevKit V1 approx 52 x 28 x 1.6 mm; actual board size/layout may vary.
esp = cube_obj("ESP32 DevKit V1 - APPROX 52x28", (52, 28, 1.6), (-30, 0, 6.2), mat_pcb, elect_col, 0.8)
# Main ESP32 module can, USB connector and pin header strips.
cube_obj("ESP32 RF module can (visual)", (18, 18, 2.0), (-30, 0, 8.0), mat_chip, elect_col, 0.4)
cube_obj("ESP32 USB connector (visual)", (8.5, 7.0, 3.8), (-57.0, 0, 6.8), mat_usb, elect_col, 0.7)
for yy in (-13.5, 13.5):
    cube_obj("ESP32 header row (visual)", (48, 1.0, 1.3), (-30, yy, 7.2), mat_usb, elect_col, 0.25)

# INMP441 breakout approx 15 x 12 mm; capsule is centred as an adjustable placeholder.
mic = cube_obj("INMP441 breakout - APPROX 15x12", (15, 12, 1.6), (35, 0, 6.2), mat_micpcb, elect_col, 0.5)
cylinder_obj("INMP441 microphone capsule (visual)", 2.0, 1.1, (35, 0, 7.55), mat_chip, elect_col)

# Curved jumper-wire reference routes. Visual only; do not use as a dimensional harness template.
def wire_curve(name, pts, mat, radius=0.48):
    curve = bpy.data.curves.new(name, 'CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 16
    curve.bevel_depth = radius
    curve.bevel_resolution = 4
    spline = curve.splines.new('BEZIER')
    spline.bezier_points.add(len(pts)-1)
    for bp, p in zip(spline.bezier_points, pts):
        bp.co = p
        bp.handle_left_type = 'AUTO'
        bp.handle_right_type = 'AUTO'
    obj = bpy.data.objects.new(name, curve)
    wire_col.objects.link(obj)
    obj.data.materials.append(mat)
    return obj

# Wire bundle is illustrated above the PCB so each colored route remains visible.
wire_curve("3V3 - red", [(-30, -7, 9.5), (-10, -20, 11), (13, -18, 13), (35, -7, 9.5)], mat_red)
wire_curve("GND - black", [(-30, -10, 9.5), (-12, -24, 12), (18, -23, 12), (35, -9, 9.5)], mat_black)
wire_curve("SCK GPIO26 - yellow", [(-9, -4, 9.5), (4, -9, 12), (20, -8, 12), (29, -4, 9.5)], mat_yellow)
wire_curve("WS GPIO25 - blue", [(-9, -1, 9.5), (4, -5, 11), (20, -4, 11), (29, -1, 9.5)], mat_blue)
wire_curve("SD GPIO33 - green", [(-9, 2, 9.5), (4, 0, 10), (20, 0, 10), (29, 2, 9.5)], mat_green)

# Text labels: scene-only, excluded from print STL exports.
def add_text(body, loc, size=3.0, mat=mat_text, align='CENTER'):
    data = bpy.data.curves.new("Text - " + body, 'FONT')
    data.body = body
    data.size = size
    data.align_x = align
    data.extrude = 0.02
    obj = bpy.data.objects.new("LABEL - " + body, data)
    obj.location = loc
    label_col.objects.link(obj)
    obj.data.materials.append(mat)
    return obj

add_text("HEART SOUND AI - ENCLOSURE", (0, 48, 54), 5.0)
add_text("ESP32 DEVKIT - approx 52 x 28 mm", (-30, 23, 9), 2.4)
add_text("INMP441 - align capsule under lid port", (35, 16, 9), 2.2)
add_text("USB ACCESS", (-56, -18, 7), 2.2)
add_text("TOP LID / MIC ACOUSTIC INLET", (35, 7, 54), 2.0)
add_text("PRINT PARTS: BASE + LID | mm units", (0, -49, 2), 2.6)

# Ground plane for attractive viewport/render presentation (not printable).
cube_obj("Display ground (not for printing)", (210, 160, 1), (0, 0, -2.0), mat_floor, set_col, 2.0)

# Scene lighting and camera.
world = bpy.data.worlds.new("Enclosure studio world") if not bpy.data.worlds else bpy.data.worlds[0]
scene.world = world
world.color = (0.025, 0.035, 0.06)

bpy.ops.object.camera_add(location=(150, -185, 155))
cam = bpy.context.object
cam.name = "Camera - exploded enclosure"
cam.rotation_euler = (Vector((0, 0, 23)) - cam.location).to_track_quat('-Z', 'Y').to_euler()
cam.data.lens = 52
scene.camera = cam
move_to_collection(cam, set_col)

for name, loc, energy, size in [
    ("Key light", (20, -70, 130), 18000, 90),
    ("Fill light", (-100, 20, 85), 11000, 80),
    ("Rim light", (70, 100, 110), 15000, 65),
]:
    bpy.ops.object.light_add(type='AREA', location=loc)
    light = bpy.context.object
    light.name = name
    light.data.energy = energy
    light.data.shape = 'DISK'
    light.data.size = size
    light.rotation_euler = (Vector((0, 0, 22)) - light.location).to_track_quat('-Z', 'Y').to_euler()
    move_to_collection(light, set_col)

scene.render.engine = 'BLENDER_EEVEE_NEXT'
scene.render.resolution_x = 1500
scene.render.resolution_y = 1050
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = str(ROOT / "Enclosure_Blender_Preview.png")
scene.render.film_transparent = False
scene.view_settings.view_transform = 'Standard'
scene.view_settings.look = 'AgX - Medium High Contrast'

# Select print parts only, with the base active.
bpy.ops.object.select_all(action='DESELECT')
base.select_set(True)
bpy.context.view_layer.objects.active = base

# Save the native Blender file in the same directory as the source and STL files.
blend_path = ROOT / "Heart_Sound_AI_Enclosure.blend"
bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
print("Saved Blender project:", blend_path)
print("Printable files: Enclosure_Base.stl and Enclosure_Lid.stl")
print("NOTE: Board models are visual placeholders. Measure actual parts before printing.")
