HEART SOUND AI ENCLOSURE - PROTOTYPE DESIGN
===========================================

FILES
-----
Enclosure_Base.stl       Printable lower tray
Enclosure_Lid.stl        Printable lid with microphone acoustic inlet
Enclosure_Assembly.step  CAD assembly for compatible CAD packages
Create_Enclosure_Blender.py  Blender scene builder; creates a native .blend
build_enclosure.py      Parametric CadQuery source for regenerating the CAD parts

IMPORTANT: A native .blend file is created by running Create_Enclosure_Blender.py
inside Blender. This environment did not have Blender installed, so the .blend
binary itself could not be generated here. The script will create it locally.

CREATE THE BLEND FILE
---------------------
1. Keep all files in this folder.
2. Open Blender.
3. Switch to the Scripting workspace.
4. In the Text Editor choose Open, then select Create_Enclosure_Blender.py.
5. Click Run Script.
6. Blender saves Heart_Sound_AI_Enclosure.blend in this folder.

PRINTING
--------
The STL files are in millimetres. Print Enclosure_Base.stl with its flat
outside bottom on the build plate. Print Enclosure_Lid.stl with its OUTSIDE
TOP FACE on the build plate (flip it upside down in the slicer), so the skirt
and acoustic guide print upward. Use 0.2 mm layers, 3 walls, 20-30% infill,
and no supports as a starting point. Check your printer and slicer preview.

Suggested material: PLA for a fit-check prototype. PETG is a reasonable choice
for a more durable enclosure. Do not use the printed part as a patient-contact
or medical-grade acoustic component.

DESIGN ASSUMPTIONS / FIT WARNINGS
--------------------------------
- Outer size: 118 x 78 x 24 mm base; lid adds 2.4 mm thickness.
- Wall and floor: 2.4 mm.
- ESP32 placeholder: 52 x 28 mm, positioned for a common DevKit-style board.
- INMP441 breakout placeholder: 15 x 12 mm.
- ESP32 and microphone use universal cable-tie slots, not guessed mounting holes.
- USB opening: 13.5 x 6 mm, positioned near the expected USB connector end.
- Lid acoustic inlet: 6.2 mm through-hole with 9.2 mm grommet counterbore.
- Four lid screws: M2.5 screws; base pilot bores are 2.3 mm. Verify fit with
  your printer/material and use appropriate short screws.
- A 5 mm locating skirt fits inside the base opening with nominal clearance.
- Acoustic inlet is aligned to the nominal centre of the microphone breakout.

These are generic prototype dimensions, not verified dimensions of your exact
ESP32 or INMP441 modules. Before printing the final version, measure both
boards, connector location, microphone capsule position, and stethoscope tube.
Use the Blender scene to move the microphone placeholder / lid hole if needed.
A short silicone grommet or coupler may be needed to seal your own tubing.
Keep the microphone sound port unobstructed. Avoid permanently gluing the
microphone or stethoscope tubing until the acoustic fit is tested.

ASSEMBLY
--------
1. Place the ESP32 in its bay and secure it with small cable ties through the
   paired floor slots. Do not let a tie crush components or short exposed pins.
2. Place the INMP441 breakout under the lid inlet, with its acoustic port facing
   the inlet. Secure gently through its tie slots; keep the MEMS port open.
3. Route wires away from the USB opening, screw posts, and lid locating skirt.
4. Check that no wire is pinched before fitting the lid.
5. Fit the lid and use four M2.5 screws. Do not overtighten.
6. Confirm USB insertion and Wi-Fi operation before closing the case permanently.

SAFETY / PROJECT LIMITATION
---------------------------
This is a school-project electronics enclosure only. It is not a medical device.
Do not use it to diagnose anyone. For controlled audio testing, use speaker
playback of public recordings. Any human recording requires teacher / guardian
approval and applicable school review.
